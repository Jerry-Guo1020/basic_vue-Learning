# Big Homework - TwoPlus

## Introduction 
<font size=6>**这个东西是我的大学第一次的前端的期末作业，我当时是用vue.js做的，所以我把它放在了这个仓库里。**</font>

## Thinking
<font size=6>**这个作业的主要内容是实现一个基于vue.js的前端页面，页面中有两个输入框，一个按钮，要求用户输入两个数字，然后点击按钮，页面会显示两个数字的和。**</font>

## Architecture
<font size=6>**肯定是用vue来框架啦**</font>


